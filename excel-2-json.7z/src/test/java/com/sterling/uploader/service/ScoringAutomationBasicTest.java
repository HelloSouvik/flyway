package com.sterling.uploader.service;


import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sterling.uploader.config.ApplicationConfiguration;
import com.sterling.uploader.config.DatabaseConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan("com.sterling")
@ContextConfiguration(classes = { ApplicationConfiguration.class, DatabaseConfiguration.class })
public class ScoringAutomationBasicTest {

	private static Logger LOGGER = LoggerFactory.getLogger(ScoringAutomationBasicTest.class);

	@Autowired
	ChargeCategoryUploaderService chargeCategoryUploaderService;
	
	@Test
	public void basicPostTest() throws IOException {
		System.out.println("Test OK");
		chargeCategoryUploaderService.run();
	}
}
