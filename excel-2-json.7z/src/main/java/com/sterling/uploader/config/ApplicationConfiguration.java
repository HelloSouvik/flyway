package com.sterling.uploader.config;

import java.util.Date;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.sterling")
public class ApplicationConfiguration {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ApplicationConfiguration.class);

	@PostConstruct
	public static void setup() {
		LOGGER.debug("Application init at: {}", new Date());
	}
	
}
