package com.sterling.uploader.service;

public interface UploaderService {
	public void run();
}
