package com.sterling.uploader.service;

public class UploaderServiceRouter{

	public void route() {
		
	}
	
}
