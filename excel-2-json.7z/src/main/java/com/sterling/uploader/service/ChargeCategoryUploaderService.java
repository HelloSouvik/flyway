package com.sterling.uploader.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sterling.uploader.model.ChargeCategory;
import com.sterling.uploader.model.UploaderConstraint.ChargeCategoryConstraint;
import com.sterling.uploader.model.UploaderConstraint.ChargeCategoryHierarchy;
import com.sterling.uploader.model.UploaderConstraint.InputFileLocation;
import com.sterling.uploader.utils.FileUtils;
import com.sterling.uploader.utils.JacksonUtils;

@Component
public class ChargeCategoryUploaderService extends AbstractUploaderService {
	
	private JacksonUtils jacksonUtils = new JacksonUtils();
	private FileUtils fileUtils = new FileUtils();

	public void run() {
		try {
			FileInputStream fileInputStream = loadFileAsInputStream(InputFileLocation.CHARGE_CATEGORY);
			Sheet sheet = readFirstExcelFileSheet(fileInputStream);
			execure(sheet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void execure(Sheet sheet) {
		Iterator<Row> rowIterator = sheet.iterator();
		ArrayList<ChargeCategory> categoryList = new ArrayList<ChargeCategory>();

		String parent_1, parent_2, parent_3, parent_4;
		ChargeCategory category_1 = null;
		ChargeCategory category_2 = null;
		ChargeCategory category_3 = null;
		ChargeCategory category_4 = null;
		rowIterator.next();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			parent_1 = row.getCell(0).getStringCellValue();
			parent_2 = row.getCell(1).getStringCellValue();
			parent_3 = row.getCell(2).getStringCellValue();
			parent_4 = row.getCell(3).getStringCellValue();
			
			if(category_1 == null || !parent_1.equalsIgnoreCase(category_1.getCategoryName())) {
				String srn = ChargeCategoryConstraint.SRN_PREFIX+parent_1;
				category_1 = populateChargeCategory(parent_1, ChargeCategoryHierarchy.LEVEL_1, ChargeCategoryConstraint.SRN_PREFIX,
						srn);	
				categoryList.add(category_1);
				category_2 = null;
				category_3 = null;
				category_4 = null;
			}
			
			if(category_2 == null || !parent_2.equalsIgnoreCase(category_2.getCategoryName())) {
				String srn = getCompositeSrn(category_1.getSrn(), parent_2);
				category_2 = populateChargeCategory(parent_2, ChargeCategoryHierarchy.LEVEL_2, category_1.getSrn(),
						srn);
				category_1.getChildren().add(category_2);
				categoryList.add(category_2);
				category_3 = null;
				category_4 = null;
			}
			
			if(category_3 == null || !parent_3.equalsIgnoreCase(category_3.getCategoryName())) {
				String srn = getCompositeSrn(category_2.getSrn(), parent_3);
				category_3 = populateChargeCategory(parent_3, ChargeCategoryHierarchy.LEVEL_3, category_2.getSrn(),
						srn);
				category_2.getChildren().add(category_3);
				categoryList.add(category_3);
				category_4 = null;
			}
			
			if(category_4 == null || !parent_4.equalsIgnoreCase(category_4.getCategoryName())) {
				String srn = getCompositeSrn(category_3.getSrn(), parent_4);
				category_4 = populateChargeCategory(parent_4, ChargeCategoryHierarchy.LEVEL_4, category_3.getSrn(),
						srn);
				category_3.getChildren().add(category_4);
				categoryList.add(category_4);
			}
		}
		
		for(ChargeCategory cat: categoryList) {
			try {
				jacksonUtils.printObjectToString(cat);
				fileUtils.getFileOutputStream(cat.getSrn().replaceAll("[^a-zA-Z0-9\\.\\-]", "_"), jacksonUtils.getObjectToString(cat));
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private String getCompositeSrn(String parentSrn, String categoryName) {
		return parentSrn + ChargeCategoryConstraint.SRN_SEPERATOR +categoryName;
	}
	
	private ChargeCategory populateChargeCategory(String categoryName, String hierarchy, String parentSrn, String srn) {
		ChargeCategory category = new ChargeCategory();
		category.setCategoryName(categoryName);
		category.setHierarchy(hierarchy);
		category.setParentSrn(parentSrn);
		category.setSrn(srn);
		return category;
	}

}
