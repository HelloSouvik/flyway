package com.sterling.uploader.service;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.sterling.uploader.utils.FileUtils;

public abstract class AbstractUploaderService implements UploaderService {
	FileUtils fileUtils = new FileUtils();
	
	public FileInputStream loadFileAsInputStream(String fileName) throws IOException {
		return fileUtils.getFileInputStream(fileName);
	}
	
	public Sheet readFirstExcelFileSheet(FileInputStream fileInputStream) throws IOException {
		Workbook workbook = WorkbookFactory.create(fileInputStream);
//        XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream); 
        return workbook.getSheetAt(0); 
	}
}
