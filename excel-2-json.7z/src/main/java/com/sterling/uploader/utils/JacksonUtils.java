package com.sterling.uploader.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JacksonUtils {
	private ObjectMapper mapper = new ObjectMapper();
	
	public <T> void printObjectToString(T t) throws JsonProcessingException {
		System.out.println(mapper.writeValueAsString(t));
	}
	
	public <T> String getObjectToString(T t) throws JsonProcessingException {
		return mapper.writeValueAsString(t);
	}
}
