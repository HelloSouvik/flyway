package com.sterling.uploader.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.sterling.uploader.model.UploaderConstraint.OutputFileLocation;

public class FileUtils {

	public String getFileContent(String fileName) throws IOException {
		File file;
		ClassLoader classLoader = getClass().getClassLoader();
		URL resource = classLoader.getResource(fileName);
		if (resource == null) {
			throw new IllegalArgumentException("file is not found!");
		} else {
			file = new File(resource.getFile());
		}

		FileReader reader = new FileReader(file);
		BufferedReader br = new BufferedReader(reader);
		StringBuffer content = new StringBuffer();
		String line;
		while ((line = br.readLine()) != null) {
			content.append(line);
		}
		return content.toString();
	}

	private static String getResourcePath() {
		try {
			URI resourcePathFile = System.class.getResource("/RESOURCE_PATH").toURI();
			String resourcePath = Files.readAllLines(Paths.get(resourcePathFile)).get(0);
			URI rootURI = new File("").toURI();
			URI resourceURI = new File(resourcePath).toURI();
			URI relativeResourceURI = rootURI.relativize(resourceURI);
			return relativeResourceURI.getPath();
		} catch (Exception e) {
			return null;
		}
	}

	public void getFileOutputStream(String fileName, String data) throws IOException {
		String fileSeparator = System.getProperty("file.separator");

		// absolute file name with path
		String absoluteFilePath = OutputFileLocation.CHARGE_CATEGORY + fileName +".json";
		File file = new File(absoluteFilePath);
		File dir = new File(OutputFileLocation.CHARGE_CATEGORY);
		
		if (!dir.exists()) {
			dir.mkdirs();
			System.out.println("Dir Created");
		} else
			System.out.println("Dir already exists");

		FileWriter writer = new FileWriter(file);
		writer.write(data);
		writer.close();

	}

	public FileInputStream getFileInputStream(String fileName) throws IOException {
		FileInputStream fileInputStream;
		ClassLoader classLoader = getClass().getClassLoader();
		URL resource = classLoader.getResource(fileName);
		if (resource == null) {
			throw new IllegalArgumentException("file is not found!");
		} else {
			File file = new File(resource.getFile());
			fileInputStream = new FileInputStream(file);
		}
		return fileInputStream;
	}

}
