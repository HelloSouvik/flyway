package com.sterling.uploader.model;

public interface UploaderConstraint {
	public interface InputFileLocation {
//		public static final String CHARGE_CATEGORY = "input/charge_category/category.xlsx";
		public static final String CHARGE_CATEGORY = "input/charge_category/category-2.xlsx";
	}

	public interface OutputFileLocation {
		public static final String CHARGE_CATEGORY = "output/charge_category/";
	}
	
	public interface OutputFolderLocation {
		public static final String CHARGE_CATEGORY = "output/charge_category/";
	}
	
	public interface ChargeCategoryConstraint{
		public static final String SRN_PREFIX = "srn::charge-categories::v1:charge-categories/";
		public static final String SRN_SEPERATOR = ":";
		
	}
	
	public interface ChargeCategoryHierarchy{
		public static final String LEVEL_1 = "LEVEL-1";
		public static final String LEVEL_2 = "LEVEL-2";
		public static final String LEVEL_3 = "LEVEL-3";
		public static final String LEVEL_4 = "LEVEL-4";
	}
	
}
