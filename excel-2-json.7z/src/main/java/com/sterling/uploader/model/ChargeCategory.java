package com.sterling.uploader.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

public class ChargeCategory {
	private String categoryName;
	private List<ChargeCategory> children;
	private String hierarchy;
	private String parentSrn;
	private String srn;

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<ChargeCategory> getChildren() {
		if(CollectionUtils.isEmpty(children)) {
			children = new ArrayList<ChargeCategory>();
		}
		return children;
	}

	public void setChildren(List<ChargeCategory> children) {
		this.children = children;
	}

	public String getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}

	public String getParentSrn() {
		return parentSrn;
	}

	public void setParentSrn(String parentSrn) {
		this.parentSrn = parentSrn;
	}

	public String getSrn() {
		return srn;
	}

	public void setSrn(String srn) {
		this.srn = srn;
	}

	@Override
	public String toString() {
		return "ChargeCategory [categoryName=" + categoryName + ", children=" + children + ", hierarchy=" + hierarchy
				+ ", parentSrn=" + parentSrn + ", srn=" + srn + "]";
	}

}
