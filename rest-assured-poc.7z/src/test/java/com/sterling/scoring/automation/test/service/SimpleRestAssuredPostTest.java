package com.sterling.scoring.automation.test.service;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sterling.scoring.automation.test.config.ApplicationConfigurationTest;
import com.sterling.scoring.automation.test.config.DatabaseConfigurationTest;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import io.qameta.allure.junit4.DisplayName;

@Epic(value = "@Epic: number: 13.0_881")
@Feature(value = "@Feature: SLG charge level")
@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan("com.sterling.scoring")
@ContextConfiguration(classes = { ApplicationConfigurationTest.class, DatabaseConfigurationTest.class })
public class SimpleRestAssuredPostTest {

	private static Logger LOGGER = LoggerFactory.getLogger(SimpleRestAssuredPostTest.class);

	@Test
	@DisplayName("@DisplayName: SimpleRestAssuredPostTest")
	@Description("@Description: SimpleRestAssuredPostTest")
	@Story("@Story: CFASD-0001")
	@Severity(SeverityLevel.BLOCKER)
	@Link(name = "JIRA", url = "http://google.com")
	@Issue("issue-124")
	public void basicGetTest() {
		get("/users?page=2").then().statusCode(200).body("page", equalTo(2));
	}

	@Test
	@DisplayName("@DisplayName: SimpleRestAssuredPostOneTest")
	@Description("@Description: SimpleRestAssuredPostOneTest")
	@Story("@Story: CFASD-0022")
	@Severity(SeverityLevel.BLOCKER)
	@Link(name = "JIRA", url = "http://google.com")
	@Issue("issue-12333")
	public void basicAnotherGetTest() {
		given().param("page", "2").get("/users").then().statusCode(200)
				.body("page", equalTo(2));
	}
	
	@Test
	@DisplayName("@DisplayName: SimpleRestAssuredPostTwoTest")
	@Description("@Description: SimpleRestAssuredPostTwoTest")
	@Story("@Story: CFASD-9900")
	@Severity(SeverityLevel.BLOCKER)
	@Link(name = "JIRA", url = "http://google.com")
	@Issue("issue-123")
	public void basicGetPrintTest() {
		String response = given().param("page", "2").get("/users").then().statusCode(200)
				.body("page", equalTo(2)).extract().asString();
		LOGGER.debug("Response : {}", response);
	}

	@Test
	public void testEquals() {
		User theBiscuit = new User("Ginger", "Ginger");
		User myBiscuit = new User("Ginger", "Ginger");
		assertThat(theBiscuit.getName(), equalTo(myBiscuit.getName()));
	}

}
