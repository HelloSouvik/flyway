INSERT INTO person (id, name, born) values (1, 'Axel', NOW());
INSERT INTO person (id, name, born) values (2, 'Mr. Foo', NOW());
INSERT INTO person (id, name, born) values (3, 'Ms. Bar', NOW());
