INSERT INTO person (id, name, born) values (4, 'Axel', NOW());
INSERT INTO person (id, name, born) values (5, 'Mr. Foo', NOW());
INSERT INTO person (id, name, born) values (6, 'Ms. Bar', NOW());
INSERT INTO person (id, name, born) values (7, 'Ms. Avi', NOW());
