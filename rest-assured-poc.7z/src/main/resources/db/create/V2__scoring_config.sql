CREATE TABLE `scoring_config` (
  `pk_scoring_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jurisdiction` varchar(200) DEFAULT NULL,
  `product` varchar(200) DEFAULT NULL,
  `product_category` varchar(200) DEFAULT NULL,
  `rule_config_json` mediumtext,
  PRIMARY KEY (`pk_scoring_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;