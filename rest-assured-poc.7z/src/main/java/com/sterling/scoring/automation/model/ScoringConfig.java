package com.sterling.scoring.automation.model;

public class ScoringConfig<E> {
	private String productCategory;
	private String product;
	private String jurisdiction;
	private CriminalRuleConfig<E> criminalRuleConfig;

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public CriminalRuleConfig<E> getCriminalRuleConfig() {
		return criminalRuleConfig;
	}

	public void setCriminalRuleConfig(CriminalRuleConfig<E> criminalRuleConfig) {
		this.criminalRuleConfig = criminalRuleConfig;
	}

}
