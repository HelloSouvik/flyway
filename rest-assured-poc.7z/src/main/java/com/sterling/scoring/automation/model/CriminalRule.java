package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class CriminalRule <E>{
	private ArrayList<ParamGroup<E>> paramGroup;

	public ArrayList<ParamGroup<E>> getParamGroup() {
		return paramGroup;
	}

	public void setParamGroup(ArrayList<ParamGroup<E>> paramGroup) {
		this.paramGroup = paramGroup;
	}
}
