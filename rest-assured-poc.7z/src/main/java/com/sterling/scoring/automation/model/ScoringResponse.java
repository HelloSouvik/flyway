package com.sterling.scoring.automation.model;

public class ScoringResponse {
	private ScoringCriminalRequest criminal;

	public ScoringCriminalRequest getCriminal() {
		return criminal;
	}

	public void setCriminal(ScoringCriminalRequest criminal) {
		this.criminal = criminal;
	}

}
