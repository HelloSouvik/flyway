package com.sterling.scoring.automation.model;

public class ScoringAutomationResource {
	private ScoringRequest scoringRequest;
	private ScoringResponse scoringResponse;

	public ScoringRequest getScoringRequest() {
		return scoringRequest;
	}

	public void setScoringRequest(ScoringRequest scoringRequest) {
		this.scoringRequest = scoringRequest;
	}

	public ScoringResponse getScoringResponse() {
		return scoringResponse;
	}

	public void setScoringResponse(ScoringResponse scoringResponse) {
		this.scoringResponse = scoringResponse;
	}
}
