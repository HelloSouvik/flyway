package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class ParamGroup<E> {
	private ArrayList<GroupDefinition<E>> groupDefinition;
	private int sequence;

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public ArrayList<GroupDefinition<E>> getGroupDefinition() {
		return groupDefinition;
	}

	public void setGroupDefinition(ArrayList<GroupDefinition<E>> groupDefinition) {
		this.groupDefinition = groupDefinition;
	}

	

}
