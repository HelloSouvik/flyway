package com.sterling.scoring.automation.model;

import java.util.ArrayList;
import java.util.Set;

public class CrimCharge {
	private String chargeLevel;
	private String dispositionType;
	private String arrestDate;
	private String ruleDecision;
	private ArrayList<String> missing;
	private int ageOfRecord;
	private int ageOfSentence;
	private int ageOfArrest;
	private int ageOfWarrant;
	private Boolean isActiveCase;
	private Boolean isDispositionDeffered;

	private String actualChargeDescription;
	private String actualDispositionType;
	private int ageOfApplicant;
	private int ageOfDisposition;
	private String ageOfRecordCma;
	private String ageOfSentenceCma;
	private int ageofSentenceProbation;
	private String ageofSentenceProbationCma;
	private int ageOnOffense;
	private Integer aorDays;
	private String convictionDate;
	private String dispositionDate;
	private String fileDate;
	private Boolean isChargeInClientDNR;
	private Boolean isChargeInGlobalDNR;
	private boolean isEqualProbationStatus;
	private Boolean isInScope;
	private Boolean isProbationActive;
	private Boolean isReportedEarlier;
	private Boolean isScoreComplete;
	private String nextCourtDate;
	private String offenseDate;
	private String systemIdentifier;
	private boolean warrantActive;
	private String warrantDate;
	private String actualChargeLevel;
	private int noOfSentence; 

	private Set<CrimSentence> sentences;
	
	private boolean match;
	private boolean misMatch;

	public int getNoOfSentence() {
		return noOfSentence;
	}

	public void setNoOfSentence(int noOfSentence) {
		this.noOfSentence = noOfSentence;
	}

	public Boolean getIsActiveCase() {
		return isActiveCase;
	}

	public void setIsActiveCase(Boolean isActiveCase) {
		this.isActiveCase = isActiveCase;
	}

	public Boolean getIsDispositionDeffered() {
		return isDispositionDeffered;
	}

	public void setIsDispositionDeffered(Boolean isDispositionDeffered) {
		this.isDispositionDeffered = isDispositionDeffered;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	public boolean isMisMatch() {
		return misMatch;
	}

	public void setMisMatch(boolean misMatch) {
		this.misMatch = misMatch;
	}

	public String getChargeLevel() {
		return chargeLevel;
	}

	public void setChargeLevel(String chargeLevel) {
		this.chargeLevel = chargeLevel;
	}

	public String getDispositionType() {
		return dispositionType;
	}

	public void setDispositionType(String dispositionType) {
		this.dispositionType = dispositionType;
	}

	public String getArrestDate() {
		return arrestDate;
	}

	public void setArrestDate(String arrestDate) {
		this.arrestDate = arrestDate;
	}

	public String getRuleDecision() {
		return ruleDecision;
	}

	public void setRuleDecision(String ruleDecision) {
		this.ruleDecision = ruleDecision;
	}

	public ArrayList<String> getMissing() {
		if (missing == null) {
			missing = new ArrayList<String>();
		}
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

	public int getAgeOfRecord() {
		return ageOfRecord;
	}

	public void setAgeOfRecord(int ageOfRecord) {
		this.ageOfRecord = ageOfRecord;
	}

	public int getAgeOfSentence() {
		return ageOfSentence;
	}

	public void setAgeOfSentence(int ageOfSentence) {
		this.ageOfSentence = ageOfSentence;
	}

	public int getAgeOfArrest() {
		return ageOfArrest;
	}

	public void setAgeOfArrest(int ageOfArrest) {
		this.ageOfArrest = ageOfArrest;
	}

	public int getAgeOfWarrant() {
		return ageOfWarrant;
	}

	public void setAgeOfWarrant(int ageOfWarrant) {
		this.ageOfWarrant = ageOfWarrant;
	}

	public String getActualChargeDescription() {
		return actualChargeDescription;
	}

	public void setActualChargeDescription(String actualChargeDescription) {
		this.actualChargeDescription = actualChargeDescription;
	}

	public String getActualDispositionType() {
		return actualDispositionType;
	}

	public void setActualDispositionType(String actualDispositionType) {
		this.actualDispositionType = actualDispositionType;
	}

	public int getAgeOfApplicant() {
		return ageOfApplicant;
	}

	public void setAgeOfApplicant(int ageOfApplicant) {
		this.ageOfApplicant = ageOfApplicant;
	}

	public int getAgeOfDisposition() {
		return ageOfDisposition;
	}

	public void setAgeOfDisposition(int ageOfDisposition) {
		this.ageOfDisposition = ageOfDisposition;
	}

	public String getAgeOfRecordCma() {
		return ageOfRecordCma;
	}

	public void setAgeOfRecordCma(String ageOfRecordCma) {
		this.ageOfRecordCma = ageOfRecordCma;
	}

	public String getAgeOfSentenceCma() {
		return ageOfSentenceCma;
	}

	public void setAgeOfSentenceCma(String ageOfSentenceCma) {
		this.ageOfSentenceCma = ageOfSentenceCma;
	}

	public int getAgeofSentenceProbation() {
		return ageofSentenceProbation;
	}

	public void setAgeofSentenceProbation(int ageofSentenceProbation) {
		this.ageofSentenceProbation = ageofSentenceProbation;
	}

	public String getAgeofSentenceProbationCma() {
		return ageofSentenceProbationCma;
	}

	public void setAgeofSentenceProbationCma(String ageofSentenceProbationCma) {
		this.ageofSentenceProbationCma = ageofSentenceProbationCma;
	}

	public int getAgeOnOffense() {
		return ageOnOffense;
	}

	public void setAgeOnOffense(int ageOnOffense) {
		this.ageOnOffense = ageOnOffense;
	}

	public Integer getAorDays() {
		return aorDays;
	}

	public void setAorDays(Integer aorDays) {
		this.aorDays = aorDays;
	}

	public String getConvictionDate() {
		return convictionDate;
	}

	public void setConvictionDate(String convictionDate) {
		this.convictionDate = convictionDate;
	}

	public String getDispositionDate() {
		return dispositionDate;
	}

	public void setDispositionDate(String dispositionDate) {
		this.dispositionDate = dispositionDate;
	}

	public String getFileDate() {
		return fileDate;
	}

	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	public Boolean getIsChargeInClientDNR() {
		return isChargeInClientDNR;
	}

	public void setIsChargeInClientDNR(Boolean isChargeInClientDNR) {
		this.isChargeInClientDNR = isChargeInClientDNR;
	}

	public Boolean getIsChargeInGlobalDNR() {
		return isChargeInGlobalDNR;
	}

	public void setIsChargeInGlobalDNR(Boolean isChargeInGlobalDNR) {
		this.isChargeInGlobalDNR = isChargeInGlobalDNR;
	}

	public boolean isEqualProbationStatus() {
		return isEqualProbationStatus;
	}

	public void setEqualProbationStatus(boolean isEqualProbationStatus) {
		this.isEqualProbationStatus = isEqualProbationStatus;
	}

	public Boolean getIsInScope() {
		return isInScope;
	}

	public void setIsInScope(Boolean isInScope) {
		this.isInScope = isInScope;
	}

	public Boolean getIsProbationActive() {
		return isProbationActive;
	}

	public void setIsProbationActive(Boolean isProbationActive) {
		this.isProbationActive = isProbationActive;
	}

	public Boolean getIsReportedEarlier() {
		return isReportedEarlier;
	}

	public void setIsReportedEarlier(Boolean isReportedEarlier) {
		this.isReportedEarlier = isReportedEarlier;
	}

	public Boolean getIsScoreComplete() {
		return isScoreComplete;
	}

	public void setIsScoreComplete(Boolean isScoreComplete) {
		this.isScoreComplete = isScoreComplete;
	}

	public String getNextCourtDate() {
		return nextCourtDate;
	}

	public void setNextCourtDate(String nextCourtDate) {
		this.nextCourtDate = nextCourtDate;
	}

	public String getOffenseDate() {
		return offenseDate;
	}

	public void setOffenseDate(String offenseDate) {
		this.offenseDate = offenseDate;
	}

	public String getSystemIdentifier() {
		return systemIdentifier;
	}

	public void setSystemIdentifier(String systemIdentifier) {
		this.systemIdentifier = systemIdentifier;
	}

	public boolean isWarrantActive() {
		return warrantActive;
	}

	public void setWarrantActive(boolean warrantActive) {
		this.warrantActive = warrantActive;
	}

	public String getWarrantDate() {
		return warrantDate;
	}

	public void setWarrantDate(String warrantDate) {
		this.warrantDate = warrantDate;
	}

	public String getActualChargeLevel() {
		return actualChargeLevel;
	}

	public void setActualChargeLevel(String actualChargeLevel) {
		this.actualChargeLevel = actualChargeLevel;
	}
	
	public Set<CrimSentence> getSentences() {
		return sentences;
	}

	public void setSentences(Set<CrimSentence> sentences) {
		this.sentences = sentences;
	}

	@Override
	public String toString() {
		return "CrimCharge [chargeLevel=" + chargeLevel + ", dispositionType=" + dispositionType + ", arrestDate="
				+ arrestDate + ", ruleDecision=" + ruleDecision + ", missing=" + missing + ", ageOfRecord="
				+ ageOfRecord + ", ageOfSentence=" + ageOfSentence + ", ageOfArrest=" + ageOfArrest + ", ageOfWarrant="
				+ ageOfWarrant + ", isActiveCase=" + isActiveCase + ", isDispositionDeffered=" + isDispositionDeffered
				+ ", actualChargeDescription=" + actualChargeDescription + ", actualDispositionType="
				+ actualDispositionType + ", ageOfApplicant=" + ageOfApplicant + ", ageOfDisposition="
				+ ageOfDisposition + ", ageOfRecordCma=" + ageOfRecordCma + ", ageOfSentenceCma=" + ageOfSentenceCma
				+ ", ageofSentenceProbation=" + ageofSentenceProbation + ", ageofSentenceProbationCma="
				+ ageofSentenceProbationCma + ", ageOnOffense=" + ageOnOffense + ", aorDays=" + aorDays
				+ ", convictionDate=" + convictionDate + ", dispositionDate=" + dispositionDate + ", fileDate="
				+ fileDate + ", isChargeInClientDNR=" + isChargeInClientDNR + ", isChargeInGlobalDNR="
				+ isChargeInGlobalDNR + ", isEqualProbationStatus=" + isEqualProbationStatus + ", isInScope="
				+ isInScope + ", isProbationActive=" + isProbationActive + ", isReportedEarlier=" + isReportedEarlier
				+ ", isScoreComplete=" + isScoreComplete + ", nextCourtDate=" + nextCourtDate + ", offenseDate="
				+ offenseDate + ", systemIdentifier=" + systemIdentifier + ", warrantActive=" + warrantActive
				+ ", warrantDate=" + warrantDate + ", actualChargeLevel=" + actualChargeLevel + ", match=" + match
				+ ", misMatch=" + misMatch + "]";
	}

}
