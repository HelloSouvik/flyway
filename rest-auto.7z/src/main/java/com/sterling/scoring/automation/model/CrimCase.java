package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class CrimCase {

	private String familyName;
	private String givenName;
	private String dob;
	private String dispositionDate;
	private String arrestDate;
	private ArrayList<String> missing;
	private ArrayList<CrimCharge> charges;
	private String chargeLevel;
	private String dispositionType;
	private int ageOfRecord;
	private int ageOfSentence;
	private Boolean isActiveCase;
	private Boolean isDispositionDeffered;

	private boolean match;

	private String addressOnRecord;
	private String firstOnRecordName;
	private String lastOnRecordName;
	private String middleInitialOnRecord;
	private String arrestingAgency;
	private String arrestTypeClassification;
	private String birthDD;
	private String birthMM;
	private String birthYYYY;
	private String caseNBR;
	private String caseType;
	private String cityOnRecord;
	private String countyOnRecord;
	private String courtOnRecord;
	private String districtCode;
	private String dlOnRecord;
	private String dobOnFile;
	private String governmentId;
	private String jailDate;
	private String postCodeOnRecord;
	private String requestAdditionalInfo;
	private String stateOnRecord;
	private String systemIdentifier;
	private String ruleDecision;

	public String getChargeLevel() {
		return chargeLevel;
	}

	public void setChargeLevel(String chargeLevel) {
		this.chargeLevel = chargeLevel;
	}

	public String getDispositionType() {
		return dispositionType;
	}

	public void setDispositionType(String dispositionType) {
		this.dispositionType = dispositionType;
	}

	public int getAgeOfRecord() {
		return ageOfRecord;
	}

	public void setAgeOfRecord(int ageOfRecord) {
		this.ageOfRecord = ageOfRecord;
	}

	public int getAgeOfSentence() {
		return ageOfSentence;
	}

	public void setAgeOfSentence(int ageOfSentence) {
		this.ageOfSentence = ageOfSentence;
	}

	public Boolean getIsActiveCase() {
		return isActiveCase;
	}

	public void setIsActiveCase(Boolean isActiveCase) {
		this.isActiveCase = isActiveCase;
	}

	public Boolean getIsDispositionDeffered() {
		return isDispositionDeffered;
	}

	public void setIsDispositionDeffered(Boolean isDispositionDeffered) {
		this.isDispositionDeffered = isDispositionDeffered;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	public ArrayList<CrimCharge> getCharges() {
		return charges;
	}

	public void setCharges(ArrayList<CrimCharge> charges) {
		this.charges = charges;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDispositionDate() {
		return dispositionDate;
	}

	public void setDispositionDate(String dispositionDate) {
		this.dispositionDate = dispositionDate;
	}

	public String getArrestDate() {
		return arrestDate;
	}

	public void setArrestDate(String arrestDate) {
		this.arrestDate = arrestDate;
	}

	public ArrayList<String> getMissing() {
		if (missing == null) {
			missing = new ArrayList<String>();
		}
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

	public String getAddressOnRecord() {
		return addressOnRecord;
	}

	public void setAddressOnRecord(String addressOnRecord) {
		this.addressOnRecord = addressOnRecord;
	}

	public String getFirstOnRecordName() {
		return firstOnRecordName;
	}

	public void setFirstOnRecordName(String firstOnRecordName) {
		this.firstOnRecordName = firstOnRecordName;
	}

	public String getLastOnRecordName() {
		return lastOnRecordName;
	}

	public void setLastOnRecordName(String lastOnRecordName) {
		this.lastOnRecordName = lastOnRecordName;
	}

	public String getMiddleInitialOnRecord() {
		return middleInitialOnRecord;
	}

	public void setMiddleInitialOnRecord(String middleInitialOnRecord) {
		this.middleInitialOnRecord = middleInitialOnRecord;
	}

	public String getArrestingAgency() {
		return arrestingAgency;
	}

	public void setArrestingAgency(String arrestingAgency) {
		this.arrestingAgency = arrestingAgency;
	}

	public String getArrestTypeClassification() {
		return arrestTypeClassification;
	}

	public void setArrestTypeClassification(String arrestTypeClassification) {
		this.arrestTypeClassification = arrestTypeClassification;
	}

	public String getBirthDD() {
		return birthDD;
	}

	public void setBirthDD(String birthDD) {
		this.birthDD = birthDD;
	}

	public String getBirthMM() {
		return birthMM;
	}

	public void setBirthMM(String birthMM) {
		this.birthMM = birthMM;
	}

	public String getBirthYYYY() {
		return birthYYYY;
	}

	public void setBirthYYYY(String birthYYYY) {
		this.birthYYYY = birthYYYY;
	}

	public String getCaseNBR() {
		return caseNBR;
	}

	public void setCaseNBR(String caseNBR) {
		this.caseNBR = caseNBR;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getCityOnRecord() {
		return cityOnRecord;
	}

	public void setCityOnRecord(String cityOnRecord) {
		this.cityOnRecord = cityOnRecord;
	}

	public String getCountyOnRecord() {
		return countyOnRecord;
	}

	public void setCountyOnRecord(String countyOnRecord) {
		this.countyOnRecord = countyOnRecord;
	}

	public String getCourtOnRecord() {
		return courtOnRecord;
	}

	public void setCourtOnRecord(String courtOnRecord) {
		this.courtOnRecord = courtOnRecord;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getDlOnRecord() {
		return dlOnRecord;
	}

	public void setDlOnRecord(String dlOnRecord) {
		this.dlOnRecord = dlOnRecord;
	}

	public String getDobOnFile() {
		return dobOnFile;
	}

	public void setDobOnFile(String dobOnFile) {
		this.dobOnFile = dobOnFile;
	}

	public String getGovernmentId() {
		return governmentId;
	}

	public void setGovernmentId(String governmentId) {
		this.governmentId = governmentId;
	}

	public String getJailDate() {
		return jailDate;
	}

	public void setJailDate(String jailDate) {
		this.jailDate = jailDate;
	}

	public String getPostCodeOnRecord() {
		return postCodeOnRecord;
	}

	public void setPostCodeOnRecord(String postCodeOnRecord) {
		this.postCodeOnRecord = postCodeOnRecord;
	}

	public String getRequestAdditionalInfo() {
		return requestAdditionalInfo;
	}

	public void setRequestAdditionalInfo(String requestAdditionalInfo) {
		this.requestAdditionalInfo = requestAdditionalInfo;
	}

	public String getStateOnRecord() {
		return stateOnRecord;
	}

	public void setStateOnRecord(String stateOnRecord) {
		this.stateOnRecord = stateOnRecord;
	}

	public String getSystemIdentifier() {
		return systemIdentifier;
	}

	public void setSystemIdentifier(String systemIdentifier) {
		this.systemIdentifier = systemIdentifier;
	}

	public String getRuleDecision() {
		return ruleDecision;
	}

	public void setRuleDecision(String ruleDecision) {
		this.ruleDecision = ruleDecision;
	}

	@Override
	public String toString() {
		return "CrimCase [familyName=" + familyName + ", givenName=" + givenName + ", dob=" + dob + ", dispositionDate="
				+ dispositionDate + ", arrestDate=" + arrestDate + ", missing=" + missing + ", chargeLevel="
				+ chargeLevel + ", dispositionType=" + dispositionType + ", ageOfRecord=" + ageOfRecord
				+ ", ageOfSentence=" + ageOfSentence + ", isActiveCase=" + isActiveCase + ", isDispositionDeffered="
				+ isDispositionDeffered + ", match=" + match + ", addressOnRecord=" + addressOnRecord
				+ ", firstOnRecordName=" + firstOnRecordName + ", lastOnRecordName=" + lastOnRecordName
				+ ", middleInitialOnRecord=" + middleInitialOnRecord + ", arrestingAgency=" + arrestingAgency
				+ ", arrestTypeClassification=" + arrestTypeClassification + ", birthDD=" + birthDD + ", birthMM="
				+ birthMM + ", birthYYYY=" + birthYYYY + ", caseNBR=" + caseNBR + ", caseType=" + caseType
				+ ", cityOnRecord=" + cityOnRecord + ", countyOnRecord=" + countyOnRecord + ", courtOnRecord="
				+ courtOnRecord + ", districtCode=" + districtCode + ", dlOnRecord=" + dlOnRecord + ", dobOnFile="
				+ dobOnFile + ", governmentId=" + governmentId + ", jailDate=" + jailDate + ", postCodeOnRecord="
				+ postCodeOnRecord + ", requestAdditionalInfo=" + requestAdditionalInfo + ", stateOnRecord="
				+ stateOnRecord + ", systemIdentifier=" + systemIdentifier + ", ruleDecision=" + ruleDecision + "]";
	}

}
