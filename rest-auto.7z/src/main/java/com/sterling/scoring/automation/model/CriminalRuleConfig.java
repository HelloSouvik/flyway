package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class CriminalRuleConfig<E> {
	private ArrayList<CriminalRule<E>> criminalRules;

	public ArrayList<CriminalRule<E>> getCriminalRules() {
		return criminalRules;
	}

	public void setCriminalRules(ArrayList<CriminalRule<E>> criminalRules) {
		this.criminalRules = criminalRules;
	}

	
	
}
