package com.sterling.scoring.automation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.sterling.scoring.automation.service.Calculator;

@SpringBootApplication
@ComponentScan("com.sterling.scoring")
public class SpringBootConsoleApplication implements CommandLineRunner {
	
	@Autowired
	Calculator calculator;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootConsoleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		int sum = calculator.add(10, 1);
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>" +sum);
	}
}
