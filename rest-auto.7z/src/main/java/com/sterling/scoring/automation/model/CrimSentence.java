package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class CrimSentence {
	private String sentenceInfo;
	private String actualSentenceType;
	private String paymentType;
	private String sanitizedSentenceType;
	private String systemIdentifier;

	private boolean match;
	private boolean misMatch;
	
	private ArrayList<String> missing;
	
	public String getSentenceInfo() {
		return sentenceInfo;
	}

	public void setSentenceInfo(String sentenceInfo) {
		this.sentenceInfo = sentenceInfo;
	}

	public String getActualSentenceType() {
		return actualSentenceType;
	}

	public void setActualSentenceType(String actualSentenceType) {
		this.actualSentenceType = actualSentenceType;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getSanitizedSentenceType() {
		return sanitizedSentenceType;
	}

	public void setSanitizedSentenceType(String sanitizedSentenceType) {
		this.sanitizedSentenceType = sanitizedSentenceType;
	}

	public String getSystemIdentifier() {
		return systemIdentifier;
	}

	public void setSystemIdentifier(String systemIdentifier) {
		this.systemIdentifier = systemIdentifier;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	public boolean isMisMatch() {
		return misMatch;
	}

	public void setMisMatch(boolean misMatch) {
		this.misMatch = misMatch;
	}

	public ArrayList<String> getMissing() {
		if(missing == null) {
			missing = new ArrayList<String>();
		}
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

}
