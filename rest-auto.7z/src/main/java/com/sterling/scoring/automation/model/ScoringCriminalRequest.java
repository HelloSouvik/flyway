package com.sterling.scoring.automation.model;

import java.util.ArrayList;

public class ScoringCriminalRequest {

	private String productCategory;
	private String product;
	private String jurisdiction;

	private String givenName;
	private String familyName;
	private String dob;
	private String ssn;
	private String rule;
	private ArrayList<CrimCase> cases;
	private ArrayList<String> missing;

	private String screeningReferenceId;
	private int screeningResultId;
	private String subjectResidentState;
	private String addressLine;
	private String cityName;
	private String gender;
	private String governmentId;
	private String middleName;
	private String postCode;
	private String licenseNumber;

	private boolean isError;
	private String errorMessage;

	private boolean match;

	public ArrayList<String> getMissing() {
		if (missing == null) {
			missing = new ArrayList<String>();
		}
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public boolean isError() {
		return isError;
	}

	public void setError(boolean isError) {
		this.isError = isError;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public ArrayList<CrimCase> getCases() {
		return cases;
	}

	public void setCases(ArrayList<CrimCase> cases) {
		this.cases = cases;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getScreeningReferenceId() {
		return screeningReferenceId;
	}

	public void setScreeningReferenceId(String screeningReferenceId) {
		this.screeningReferenceId = screeningReferenceId;
	}

	public int getScreeningResultId() {
		return screeningResultId;
	}

	public void setScreeningResultId(int screeningResultId) {
		this.screeningResultId = screeningResultId;
	}

	public String getSubjectResidentState() {
		return subjectResidentState;
	}

	public void setSubjectResidentState(String subjectResidentState) {
		this.subjectResidentState = subjectResidentState;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGovernmentId() {
		return governmentId;
	}

	public void setGovernmentId(String governmentId) {
		this.governmentId = governmentId;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

}
