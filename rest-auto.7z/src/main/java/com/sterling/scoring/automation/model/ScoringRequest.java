package com.sterling.scoring.automation.model;

public class ScoringRequest {
	private ScoringCriminalRequest criminal;

	public ScoringCriminalRequest getCriminal() {
		return criminal;
	}

	public void setCriminal(ScoringCriminalRequest criminal) {
		this.criminal = criminal;
	}

}
