CREATE TABLE person (
    id int not null,
    name varchar(100) not null,
    born TIMESTAMP
);
