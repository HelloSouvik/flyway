package com.sterling.scoring.automation.test.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:config/application.properties")
public class DatabaseConfigurationTest {
	
}
