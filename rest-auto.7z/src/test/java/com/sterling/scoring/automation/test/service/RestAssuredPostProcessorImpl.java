package com.sterling.scoring.automation.test.service;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sterling.scoring.automation.model.ScoringAutomationResource;
import com.sterling.scoring.automation.model.ScoringResponse;
import com.sterling.scoring.automation.test.utils.FileLoaderUtils;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestAssuredPostProcessorImpl {

	private static final String SUB_PATH_REQUEST = "";
	private FileLoaderUtils fileUtils = new FileLoaderUtils();
	private ObjectMapper mapper = new ObjectMapper();

	public ScoringResponse invokeScoringServicePost(String fileName) throws IOException {
		ScoringAutomationResource resources = getAutomationResource(fileName);
		ScoringResponse response = given().contentType(ContentType.JSON).body(fromResourceToRequestJson(resources)).post(SUB_PATH_REQUEST).then()
				.statusCode(200).extract().as(ScoringResponse.class);
		return response;
	}

	public ScoringAutomationResource getAutomationResource(String fileName) throws IOException {
		String content = fileUtils.loadFileFromResourceFolder(fileName);
		return fromJsonToResource(content);
	}

	private ScoringAutomationResource fromJsonToResource(String json)
			throws JsonParseException, JsonMappingException, IOException {
		return mapper.readValue(json, ScoringAutomationResource.class);
	}

	private String fromResourceToRequestJson(ScoringAutomationResource resources)
			throws JsonParseException, JsonMappingException, IOException {
		return mapper.writeValueAsString(resources.getScoringRequest());
	}
}
