package com.sterling.scoring.automation.test.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

import org.springframework.stereotype.Component;

@Component
public class FileLoaderUtils {

	public String loadFileFromResourceFolder(String fileName) throws IOException {
		File file;
		ClassLoader classLoader = getClass().getClassLoader();
		URL resource = classLoader.getResource(fileName);
		if (resource == null) {
			throw new IllegalArgumentException("file is not found!");
		} else {
			file = new File(resource.getFile());
		}
		
		FileReader reader = new FileReader(file);
		BufferedReader br = new BufferedReader(reader);
		StringBuffer content = new StringBuffer();
		String line;
		while ((line = br.readLine()) != null) {
			content.append(line);
		}
		return content.toString();
	}

}
