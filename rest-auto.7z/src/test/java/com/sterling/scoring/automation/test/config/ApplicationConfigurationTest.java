package com.sterling.scoring.automation.test.config;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import io.restassured.RestAssured;

@Configuration
public class ApplicationConfigurationTest {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ApplicationConfigurationTest.class);

	@PostConstruct
	public static void setup() {
		String port = System.getProperty("server.port");
		String basePath = System.getProperty("server.base");
		String baseHost = System.getProperty("server.host");

		if (port == null) {
			port = "443";
		} 
		RestAssured.port = Integer.valueOf(port);
		if (basePath == null) {
			basePath = "/api/";
		}
		RestAssured.basePath = basePath;
		if (baseHost == null) {
			baseHost = "https://reqres.in";
		}
		RestAssured.baseURI = baseHost;
		RestAssured.useRelaxedHTTPSValidation();
		LOGGER.debug("Application REST-assured sertup done for server: {}, on port: {}, with base context: {}", baseHost, port, basePath);
	}
	
}
