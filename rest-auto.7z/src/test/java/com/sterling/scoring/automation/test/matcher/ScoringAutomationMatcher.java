package com.sterling.scoring.automation.test.matcher;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import com.sterling.scoring.automation.model.ScoringAutomationResource;

public class ScoringAutomationMatcher extends TypeSafeMatcher<Object> {

	private ScoringAutomationResource resources;

	public ScoringAutomationMatcher(ScoringAutomationResource resources) {
		super();
		this.resources = resources;
	}

	@Override
	public void describeTo(Description description) {
		
	}

	@Override
	protected boolean matchesSafely(Object item) {
		return false;
	}

	public ScoringAutomationResource getResources() {
		return resources;
	}

	public void setResources(ScoringAutomationResource resources) {
		this.resources = resources;
	}

}
