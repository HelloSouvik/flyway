package com.sterling.scoring.automation.test.service;

import org.junit.Test;

import io.qameta.allure.Attachment;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.junit4.DisplayName;

@Epic(value = "@Epic: number: 12.0_91")
@Feature(value = "@Feature: String predicate check")
public class VanillaTest {

	@Test
	@DisplayName("@DisplayName: Human-readable test name")
	@Description("@Description: Some detailed test description")
	@Story("@Story: CFASD-0000")
	@Severity(SeverityLevel.BLOCKER)
	@Link(name = "JIRA", url = "http://google.com")
	@Issue("issue-123")
    public void testOk() {
        System.out.println("Test OK");
        performedActions("calling attachment....");
    }
	
	@Attachment(type = "text/plain", value = "SomeName")
	public String performedActions(String actionSequence) {
	    return actionSequence.toString();
	}

	
	@Step("Type {user.name} / {user.password}.")
	public void loginWith(User user) {
		stepOne(user.getName(), user.getPassword());
	}
	
	@Step("step to verify userName {0} and passowrd {1}")	
	public void stepOne(String userName, String password) {
        System.out.println("Test OK");
        subStepOne("sub-Souvik", "sub-password1234");
    }
	
	@Step("Second step to verify userName {0} and passowrd {1}")	
	public void stepSecond(String userName, String password) {
        System.out.println("Test OK");
        subStepSecond("sub-Second-Souvik", "sub-Second-password1234");
    }
	
	@Step("Another sub-step to verify userName {0} and passowrd {1}")	
	public void subStepOne(String userName, String password) {
        System.out.println("Test OK");
    }
	
	@Step("Another Second sub-step to verify userName {0} and passowrd {1}")	
	public void subStepSecond(String userName, String password) {
        System.out.println("Test OK");
    }
	
}
