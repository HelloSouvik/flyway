package com.sbig.chekpoint.bugfix.core.test;

public class ChekpointLambdaHandlerUTest {

}
